#! /bin/bash

java -classpath bin Main