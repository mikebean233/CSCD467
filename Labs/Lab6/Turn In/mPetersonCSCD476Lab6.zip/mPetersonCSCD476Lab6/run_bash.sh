#! /bin/bash
java -classpath bin MyBarrierTester