public class BrokenBarrierException extends Exception {
    public BrokenBarrierException(){}
    public BrokenBarrierException(String message){super(message);}
}
