public class LastCommand implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("All Thread Reached this Barrier Point!");
	}
}
