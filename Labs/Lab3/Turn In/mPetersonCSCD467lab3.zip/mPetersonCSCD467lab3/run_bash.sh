#! /bin/bash

java -classpath bin Alternation