#! /bin/bash
java -classpath bin RandomCharacters