#! /bin/bash

java -classpath bin MainWindow