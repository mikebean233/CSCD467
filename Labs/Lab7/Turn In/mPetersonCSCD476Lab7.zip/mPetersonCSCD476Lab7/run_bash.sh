#! /bin/bash
java -classpath ./bin Diners