#! /bin/bash
set -x
hadoop fs -rm -r "$1"/output

